# THIS IS AN AUTO-GENERATED FILE. DO NOT CHANGE.

from .entity_test_interface import EntityTestInterface
from .part_test_interface import PartTestInterface
from .sketch_test_interface import SketchTestInterface
from .landmark_test_interface import LandmarkTestInterface
from .joint_test_interface import JointTestInterface
from .material_test_interface import MaterialTestInterface
from .animation_test_interface import AnimationTestInterface
from .light_test_interface import LightTestInterface
from .camera_test_interface import CameraTestInterface
from .render_test_interface import RenderTestInterface
from .scene_test_interface import SceneTestInterface
from .analytics_test_interface import AnalyticsTestInterface

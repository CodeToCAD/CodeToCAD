from enum import Enum


class CurveTypes(Enum):
    POLY = 0
    NURBS = 1
    BEZIER = 2

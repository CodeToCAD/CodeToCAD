from enum import Enum


class Units(Enum):
    pass

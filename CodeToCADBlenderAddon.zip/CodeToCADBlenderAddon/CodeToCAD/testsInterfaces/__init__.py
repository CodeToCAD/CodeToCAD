# THIS IS AN AUTO-GENERATED FILE. DO NOT CHANGE.

from .EntityTestInterface import EntityTestInterface
from .PartTestInterface import PartTestInterface
from .SketchTestInterface import SketchTestInterface
from .LandmarkTestInterface import LandmarkTestInterface
from .JointTestInterface import JointTestInterface
from .MaterialTestInterface import MaterialTestInterface
from .AnimationTestInterface import AnimationTestInterface
from .LightTestInterface import LightTestInterface
from .CameraTestInterface import CameraTestInterface
from .RenderTestInterface import RenderTestInterface
from .SceneTestInterface import SceneTestInterface
from .AnalyticsTestInterface import AnalyticsTestInterface

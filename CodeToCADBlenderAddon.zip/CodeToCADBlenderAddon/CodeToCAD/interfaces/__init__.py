# THIS IS AN AUTO-GENERATED FILE. DO NOT CHANGE.

from .EntityInterface import EntityInterface
from .PartInterface import PartInterface
from .SketchInterface import SketchInterface
from .LandmarkInterface import LandmarkInterface
from .JointInterface import JointInterface
from .MaterialInterface import MaterialInterface
from .AnimationInterface import AnimationInterface
from .LightInterface import LightInterface
from .CameraInterface import CameraInterface
from .RenderInterface import RenderInterface
from .SceneInterface import SceneInterface
from .AnalyticsInterface import AnalyticsInterface

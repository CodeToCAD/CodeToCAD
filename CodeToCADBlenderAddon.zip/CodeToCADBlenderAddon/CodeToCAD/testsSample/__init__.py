# THIS IS AN AUTO-GENERATED FILE. DO NOT CHANGE.

from .EntityTest import EntityTest
from .PartTest import PartTest
from .SketchTest import SketchTest
from .LandmarkTest import LandmarkTest
from .JointTest import JointTest
from .MaterialTest import MaterialTest
from .AnimationTest import AnimationTest
from .LightTest import LightTest
from .CameraTest import CameraTest
from .RenderTest import RenderTest
from .SceneTest import SceneTest
from .AnalyticsTest import AnalyticsTest

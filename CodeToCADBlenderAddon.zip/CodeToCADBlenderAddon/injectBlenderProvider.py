
from typing import Optional


def injectBlenderProvider(globalContext: Optional[dict]) -> None:
    from CodeToCAD import setPartProvider, setSketchProvider, setMaterialProvider, setLandmarkProvider, setJointProvider, setAnimationProvider, setSceneProvider, setAnalyticsProvider, setCameraProvider, setLightProvider, setRenderProvider

    from blenderProvider import Part, Sketch, Material, Landmark, Joint, Animation, Scene, Analytics, Camera, Light, Render

    setPartProvider(Part, globalContext)
    setSketchProvider(Sketch, globalContext)
    setMaterialProvider(Material, globalContext)
    setLandmarkProvider(Landmark, globalContext)
    setJointProvider(Joint, globalContext)
    setAnimationProvider(Animation, globalContext)
    setSceneProvider(Scene, globalContext)
    setAnalyticsProvider(Analytics, globalContext)
    setCameraProvider(Camera, globalContext)
    setLightProvider(Light, globalContext)
    setRenderProvider(Render, globalContext)
